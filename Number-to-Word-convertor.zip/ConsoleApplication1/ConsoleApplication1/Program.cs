﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        public Program()
        {
            strNumberDic.Add(1,"One");
            strNumberDic.Add(2, "Two");
            strNumberDic.Add(3, "Three");
            strNumberDic.Add(4, "Four");
            strNumberDic.Add(5, "Five");
            strNumberDic.Add(6, "Six");
            strNumberDic.Add(7, "Seven");
            strNumberDic.Add(8, "Eight");
            strNumberDic.Add(9, "Nine");
            strNumberDic.Add(10, "Ten");
            strNumberDic.Add(11, "Eleven");
            strNumberDic.Add(12, "Twelve");
            strNumberDic.Add(13, "Thirteen");
            strNumberDic.Add(14, "Fourteen");
            strNumberDic.Add(15, "Fifteen");
            strNumberDic.Add(16, "Sixteen");
            strNumberDic.Add(17, "Sventeen");
            strNumberDic.Add(18, "Eighteen");
            strNumberDic.Add(19, "Nineteen");
            strNumberDic.Add(20, "Twenty");
            strNumberDic.Add(30, "Thirty");
            strNumberDic.Add(40, "Fourty");
            strNumberDic.Add(50, "Fifty");
            strNumberDic.Add(60, "Sixty");
            strNumberDic.Add(70, "Seventy");
            strNumberDic.Add(80, "Eighty");
            strNumberDic.Add(90, "Ninety");
            strNumberDic.Add(100, "Hundered");
        }
        static void Main(string[] args)
        {
            getNum: var i = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(new Program().ConvertIntToString(i));
            goto getNum;
        }
        Dictionary<int, String> strNumberDic = new Dictionary<int, String>();
        String GetTwoDigitNumber(int Num)
        {
            String TempNumber, strNum = "";
            strNumberDic.TryGetValue(Num - Num % 10, out TempNumber);
            strNum = TempNumber + " ";
            strNumberDic.TryGetValue(Num % 10, out TempNumber);
            strNum += TempNumber;
            return strNum;
        }
        String GetThreeDigitNumber(int num)
        {
            String tempNumber, strNum = "";
            strNumberDic.TryGetValue(num % 1000, out tempNumber);
            string val = GetTwoDigitNumber(num % 100);
            if(!string.IsNullOrWhiteSpace(val))
            {
                strNum = strNum + " and " + val;
            }
            else
            {
                strNum = " " + strNum;
            }
            return strNum;
        }
        public  String ConvertIntToString(int num)
        {
            String strNum = "";
            if(num<=20)
            {
                if(!strNumberDic.TryGetValue(num,out strNum))
                {
                    strNum = "Number not Exist";
                }

            }
            else if(num<=100)
            {
                strNum = GetTwoDigitNumber(num);
            }
            else if(num<1000)
            {
                strNum = GetThreeDigitNumber(num);
            }
            else
            {
                String tempNumber = "";
                strNumberDic.TryGetValue(num / 1000, out tempNumber);
                strNum = tempNumber + " " + "Thousand";
                if(num>1000)
                {
                    strNum += GetThreeDigitNumber(num - 1000);

                }
            }
            return strNum;
            
        }
    }
}
